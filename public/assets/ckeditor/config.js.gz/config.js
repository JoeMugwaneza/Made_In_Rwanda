(function() {
  CKEDITOR.editorConfig = function(config) {
    config.language = "english";
    config.uiColor = "#AADC6E";
    return true;
  };

}).call(this);
